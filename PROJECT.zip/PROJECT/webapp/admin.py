from django.contrib import admin
from .models import mod

# Register your models here.

admin.site.register(mod)